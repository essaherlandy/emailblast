<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MemberLogin extends Model
{
    protected $table = 'member_login';
}
