<?php $__env->startSection('content'); ?>
<table width="640" cellpadding="0" cellspacing="0" border="0" class="wrapper" bgcolor="#FFFFFF">
    <tr>
        <td align="center" valign="top">

            <table width="600" cellpadding="0" cellspacing="0" border="0" class="container">
                <tr>
                    <td width="600" class="mobile" align="center" valign="top">
                        <h1> <?php echo e($data['title']); ?> </h1>
                    </td>
                </tr>
                <tr>
                    <td width="600" class="mobile" align="center" valign="top">
                        <p class="ft-sz-16" style="padding-left: 20px; padding-right: 20px;">
                            <?php echo $data['description']; ?>

                        </p>
                    </td>
                </tr>
            </table>

        </td>
    </tr>
    <tr>
        <td height="10" style="font-size:10px; line-height:10px;">&nbsp;</td>
    </tr>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\email\resources\views/mail/blast-email.blade.php ENDPATH**/ ?>